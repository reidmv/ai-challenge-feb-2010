
#ifndef ASTAR_H
#define ASTAR_H

#include "ai.h"
#include "map.h"
#include "loc.h"
#include "astarnode.h"
#include <list>
#include <sys/time.h>
namespace AI{class AStar{public:AStar(void);~AStar(void);std::list<Loc> search(Loc &p_start,Loc &p_end,Map &p_map,bool include_origin=false,int margin=USEC_MAXTIME);private:std::list<AStarNode> openList;std::list<Loc> closedList;AStarNode *curr_node;Loc *start;Loc *end;Map *map;struct timeval t_beg;struct timeval t_end;struct timeval t_tot;AStarNode*leastCost();int costFrom(AStarNode &loc);void addAdjacent(AStarNode &curr);bool inClosed(Loc &curr);};}
#endif
