
#ifndef AI_H
#define AI_H

#define DEBUG
namespace AI{const int USEC_MAXTIME=600000;const int SKIRT_MOVES=1;const int FILL_MOVES=30;const int CHARGE_STOP=4;}
#endif
