
#ifndef BOT_H
#define BOT_H

#include "map.h"
#include "loc.h"
#include "astar.h"
#include "longestpath.h"
#include <list>
namespace AI{class Bot{public:Bot(void);~Bot(void);enum State{CHARGE,FILL,SKIRT,NECKTONECK,LEADING};Loc makeMove(Map &map);private:int counter;State state;std::list<Loc> path;std::list<Loc> adjacencies;AStar astar;LongestPath longestpath;Loc player;Loc opponent;struct timeval t_beg;struct timeval t_end;struct timeval t_tot;void charge(Map &map);void fill(Map &map);void skirt(Map &map);void necktoneck(Map &map);void leading(Map &map);void simple(Map &map);void checkCloseQuarters(void);int calcBestPath(Loc &loc,Map &map);bool chooseSides(Map &map);int hasChokepoint(std::list<Loc>&chokepath,Map &map);};}
#endif
