
#ifndef LONGESTPATH_H
#define LONGESTPATH_H

#include "ai.h"
#include "map.h"
#include "loc.h"
#include <list>
#include <sys/time.h>
namespace AI{class LongestPath{public:LongestPath();~LongestPath();std::list<Loc> search(Loc &start,Map &map,int maxtime=USEC_MAXTIME);std::list<Loc> continueSearch(Loc &start,Map &map,int maxtime=USEC_MAXTIME);private:std::list<Loc> path;std::list<Loc> longest_path;std::list<Loc> emptyAdjacency;std::list<std::list<Loc> > adjacencyList;struct timeval t_beg;struct timeval t_end;struct timeval t_tot;std::list<Loc>&newSearch(Loc &start,Map &map,int maxtime);std::list<Loc>&generatePath(Loc &start,Map &map,int maxtime);std::list<Loc> getAdjacencies(Loc &loc,Map &map);bool inPath(Loc &loc);};}
#endif
