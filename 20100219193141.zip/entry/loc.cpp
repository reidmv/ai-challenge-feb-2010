
#include "loc.h"
#include <cmath>
#include <cstdlib>
Loc::Loc(int init_row,int init_col){row=init_row;col=init_col;}Loc::~Loc(void){}int Loc::getRow(void)const{return row;}int Loc::getCol(void)const{return col;}Loc&Loc::setRow(int new_row){row=new_row;return *this;}Loc&Loc::setCol(int new_col){col=new_col;return *this;}int Loc::distanceFrom(const Loc &comp)const{int x=this->row-comp.row;int y=this->col-comp.col;return((x*x)+(y*y));}bool Loc::operator==(const Loc &comp)const{return(this->row==comp.row&&this->col==comp.col);}bool Loc::operator!=(const Loc &comp)const{return(this->row!=comp.row||this->col!=comp.col);}