
#ifndef LOC_H
#define LOC_H
class Loc{public:Loc(int init_row=0,int init_col=0);~Loc(void);int getRow(void)const;int getCol(void)const;Loc&setRow(int new_row);Loc&setCol(int new_col);int distanceFrom(const Loc &comp)const;bool operator==(const Loc &comp)const;bool operator!=(const Loc &comp)const;private:int row;int col;};
#endif
