
#include "astarnode.h"
#include <cstdio>
using namespace AI;AStarNode::AStarNode(void){prev=0;}AStarNode::~AStarNode(void){}AStarNode*AStarNode::getPrev(void)const{return prev;}void AStarNode::set(const Loc &new_loc,AStarNode *new_prev){if(&new_loc==0){return;}setRow(new_loc.getRow());setCol(new_loc.getCol());prev=new_prev;return;}void AStarNode::set(int x,int z,AStarNode *new_prev){setRow(x);setCol(z);prev=new_prev;return;}